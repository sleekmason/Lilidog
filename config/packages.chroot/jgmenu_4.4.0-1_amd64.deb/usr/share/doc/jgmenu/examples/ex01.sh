#!/bin/sh

../jgmenu --simple --config-file=ex01/jgmenurc < ex01/menu.csv
