#!/bin/sh

../jgmenu --simple --csv-file=ex05/root.csv
